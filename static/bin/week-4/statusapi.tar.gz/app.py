import os
import socket
import time
from flask import Flask, jsonify

app = Flask(__name__)
start_time = time.time()


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"}), 200


@app.route("/api/v1/status", methods=["GET"])
def status():
    uptime_seconds = int(time.time() - start_time)
    return jsonify({
        "service": "statusapi",
        "version": "1.0.0",
        "hostname": socket.gethostname(),
        "uptime_seconds": uptime_seconds,
        "status": "running"
    }), 200


if __name__ == "__main__":
    port = int(os.environ.get("STATUSAPI_PORT", 8090))
    host = os.environ.get("STATUSAPI_HOST", "127.0.0.1")
    app.run(host=host, port=port)
